from win10toast import ToastNotifier
#from win11toast import toast

#toast = toast()
toast = ToastNotifier()

#def ts(mes1,mes2):
#    #toast(mes1,mes2, duration=3)#,duration=3,icon_path="113.ico")
#    toast.show_toast("Удаление абонента","Удаление абонента прошло успешно",duration=3,icon_path="113.ico", threaded=True)
#    return 0

#ts("Удаление абонента","Все будет хорошо")
#toast.show_toast("Удаление абонента","Удаление абонента прошло успешно",duration=3,icon_path="113.ico", threaded=True)

try:
    toast.show_toast("Удаление абонента", "Удаление абонента прошло успешно", duration=3, icon_path="113.ico",
                     threaded=True)
except:
    pass