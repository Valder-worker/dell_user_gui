import logging
from time import strftime, localtime, sleep

import keyboard
import pyautogui
from python_imagesearch.imagesearch import imagesearch_numLoop
from win10toast import ToastNotifier

logging.basicConfig(filename='app.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
toast = ToastNotifier()

toast.show_toast("Удаление абонента","Программа запущена, висит в памяти и нигде не отсвечивает. Для запуска используйте клавиши ALT+Z",duration=5,icon_path="113.ico")
def locate_and_click(image_path):
    #pos = imagesearch_loop(image_path,1)#, confidence=0.9)
    pos = imagesearch_numLoop(image_path,0.2,7)
    if pos[0] != -1:
        #print("position: ", pos[0], pos[1])
        logging.info("position: %s, %s", pos[0], pos[1])
        pyautogui.click(pos[0]+5, pos[1]+5)
        sleep(0.5)
        return True
    else:
        #print(" Изображение не найдено")
        logging.warning("Изображение не найдено")
        sleep(0.5)
        return False

def main():
    while True:
        print("Начало цикла, для запуска использовать ALT+Z")
        keyboard.wait('Alt + Z')
        logging.info("--------Начало цикла--------")
        #sleep(1)
        if locate_and_click("pict/is1.bmp"):
            #print("Найдена картинка Изменить свойства, кликаем на него")
            logging.info("Найдена картинка Изменить свойства, кликаем на него")
            if locate_and_click("pict/zpp1.bmp"):
                #print("Нашли запрет приема платежей без галочки, кликаем по нему")
                logging.info("Нашли запрет приема платежей без галочки, кликаем по нему")
                pyautogui.scroll(-400)
                sleep(0.5)
                #print("Скролим вниз страницы")
                logging.info("Скролим вниз страницы")
                if locate_and_click("pict/save.bmp"):
                    #print("Нашли сохранить и кликнули по ней")
                    logging.info("Нашли сохранить и кликнули по ней")
                    if locate_and_click("pict/is1.bmp"):
                        #print("Нашли свойства 2")
                        logging.info("Нашли свойства 2")
                        if locate_and_click("pict/ik1.bmp"):
                            #print("Нашли изменение класса и кликнули по нему")
                            logging.info("Нашли изменение класса и кликнули по нему")
                            if locate_and_click("pict/del.bmp"):
                                #print("Нашли кнопку удаление и кликаем по ней")
                                logging.info("Нашли кнопку удаление и кликаем по ней")
                                if locate_and_click("pict/oi1.bmp"):
                                    #print("Нашли основную информацию, кликаем на нее")
                                    logging.info("Нашли основную информацию, кликаем на нее")
                                    logging.info("Скриншот удаленной учетки")
                                    sleep(0.5)
                                    pyautogui.screenshot('screen/' + strftime('%Y-%m-%d_%H.%M.%S', localtime()) + '.jpg')
                                    toast.show_toast("Удаление абонента", "Удаление абонента прошло успешно",
                                                     duration=3, icon_path="113.ico")
                                else:
                                    #print("Не найдена основная информация")
                                    logging.error("Не найдена основная информация")
                                    pyautogui.screenshot(
                                        'screen/' + "Ошибка 6 _ " + strftime('%Y-%m-%d_%H.%M.%S', localtime()) + '.jpg')
                            else:
                                #print("Не найдена кнопка удаления")
                                logging.error("Не найдена кнопка удаления")
                                pyautogui.screenshot(
                                    'screen/' + "Ошибка 6 _ " + strftime('%Y-%m-%d_%H.%M.%S', localtime()) + '.jpg')
                        else:
                            #print("Не найдено изменение класса")
                            logging.error("Не найдено изменение класса")
                            pyautogui.screenshot(
                                'screen/' + "Ошибка 5 _ " + strftime('%Y-%m-%d_%H.%M.%S', localtime()) + '.jpg')
                    else:
                        #print("Не нашли свойства 2")
                        logging.error("Не нашли свойства 2")
                        pyautogui.screenshot(
                            'screen/' + "Ошибка 4 _ " + strftime('%Y-%m-%d_%H.%M.%S', localtime()) + '.jpg')
                else:
                    #print("Не нашли кнопку сохранить")
                    logging.error("Не нашли кнопку сохранить")
                    pyautogui.screenshot('screen/' + "Ошибка 3 _ " + strftime('%Y-%m-%d_%H.%M.%S', localtime()) + '.jpg')
            else:
                #print("не найдена картинка пустой запрет платежей")
                logging.error("не найдена картинка пустой запрет платежей")
                pyautogui.screenshot('screen/' + "Ошибка 2 _ " + strftime('%Y-%m-%d_%H.%M.%S', localtime()) + '.jpg')
        else:
            #print("не найдена картинка изменить свойства")
            logging.error("не найдена картинка изменить свойства")
            pyautogui.screenshot('screen/' + "Ошибка 1 _ " + strftime('%Y-%m-%d_%H.%M.%S', localtime()) + '.jpg')
        #pyautogui.screenshot('screen/' + strftime('%Y-%m-%d_%H.%M.%S', localtime()) + '.jpg')

if __name__ == "__main__":
    main()