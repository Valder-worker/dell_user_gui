import pyautogui
import keyboard
from time import strftime, localtime
while True:
    print("Начало цикла, ждем комбинации клавиш для запуска")
    keyboard.wait('Alt + Z') #keyboard.wait('Ctrl + Q')
    pyautogui.sleep(1)
    try: #провека на наличие изменить свойства
        im = pyautogui.locateOnScreen("pict/is1.bmp")
        pyautogui.click(im)
        pyautogui.sleep(0.5)
        print("найдена картинка Изменить свойства, кликаем на него")
        try: #Проверка на отсутствии галочки запрета платежей
            im = pyautogui.locateOnScreen("pict/zpp1.bmp")
            pyautogui.click(im) #кликаем по запрету платежей
            print("Нашли запрет приема платежей без галочки, кликаем по нему")
            pyautogui.sleep(0.5)
            pyautogui.scroll(-400)
            pyautogui.sleep(0.5)
            print("Скролим вниз страницы")
            try: #проверка на наличии кнопки сохранить
                im = pyautogui.locateOnScreen("pict/save.bmp")
                pyautogui.click(im)
                print("Нашли сохранить и кликнули по ней")
                pyautogui.sleep(1)
                try: #Ищем снова свойства 2
                    im = pyautogui.locateOnScreen("pict/is1.bmp")
                    pyautogui.click(im)
                    pyautogui.sleep(1)
                    try: # проверка на наличие изменения класса
                        im = pyautogui.locateOnScreen("pict/ik1.bmp")
                        pyautogui.click(im)
                        print("Нашли изменение класса и кликнули по нему")
                        pyautogui.sleep(1)
                        try: # проверяем кнопку удаления
                            im = pyautogui.locateOnScreen("pict/del.bmp")
                            pyautogui.click(im)
                            print("Нашли кнопку удаление и кликаем по ней")
                            pyautogui.sleep(0.5)
                            try: #проверка на наличие основной информации
                                im = pyautogui.locateOnScreen("pict/oi1.bmp")
                                pyautogui.click(im)
                                print("Нашли основную информацию, кликаем на нее и будем делать сриншот")
                            except:#если не нашли основную информацию
                                print("Не найдена основная информация")
                        except: # если не нашли кнопку удаления
                            print("Не найдена кнопка удаления")
                    except:#если не найдено изменение класса
                        print("Не найдено изменение класса")
                except: #Если не нашли снова свойства 2
                    print("Не нашли свойства 2")
            except: #Если не нашли кнопку сохранения
                print("Не нашли кнопку сохранить")
        except: #Если не нашли пустую галочку запрета платежей.
            print("не найдена картинка пустой запрет платежей")
    except: #этот блок, если не найдено изменить свойства
        print("не найдена картинка изменить свойства")
    pyautogui.sleep(0.5)
    pyautogui.screenshot('screen/' + strftime('%Y-%m-%d_%H.%M.%S', localtime()) + '.jpg')
