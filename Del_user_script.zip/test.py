from python_imagesearch.imagesearch import imagesearch_loop
import pyautogui
import keyboard
from time import strftime, localtime, sleep

def locate_and_click(image_path):
    pos = imagesearch_loop(image_path,1)#, confidence=0.9)
    if pos[0] != -1:
        print("position: ", pos[0], pos[1])
        pyautogui.click(pos[0]+5, pos[1]+5)
        sleep(0.5)
        return True
    else:
        print(" Изображение не найдено")
        sleep(0.5)
        return False

def main():
    while True:
        print("Начало цикла, ждем комбинации клавиш для запуска")
        keyboard.wait('Alt + Z')
        sleep(1)

        if locate_and_click("pict/is1.bmp"):
            print("Найдена картинка Изменить свойства, кликаем на него")
            if locate_and_click("pict/zpp1.bmp"):
                print("Нашли запрет приема платежей без галочки, кликаем по нему")
                pyautogui.scroll(-400)
                sleep(0.5)
                print("Скролим вниз страницы")
                if locate_and_click("pict/save.bmp"):
                    print("Нашли сохранить и кликнули по ней")
                    if locate_and_click("pict/is1.bmp"):
                        print("Нашли свойства 2")
                        if locate_and_click("pict/ik1.bmp"):
                            print("Нашли изменение класса и кликнули по нему")
                            if locate_and_click("pict/del.bmp"):
                                print("Нашли кнопку удаление и кликаем по ней")
                                if locate_and_click("pict/oi1.bmp"):
                                    print("Нашли основную информацию, кликаем на нее и будем делать сриншот")
                                else:
                                    print("Не найдена основная информация")
                            else:
                                print("Не найдена кнопка удаления")
                        else:
                            print("Не найдено изменение класса")
                    else:
                        print("Не нашли свойства 2")
                else:
                    print("Не нашли кнопку сохранить")
            else:
                print("не найдена картинка пустой запрет платежей")
        else:
            print("не найдена картинка изменить свойства")

        sleep(0.5)
        pyautogui.screenshot('screen/' + strftime('%Y-%m-%d_%H.%M.%S', localtime()) + '.jpg')

if __name__ == "__main__":
    main()