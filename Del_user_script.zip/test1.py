from python_imagesearch.imagesearch import imagesearch_loop
import pyautogui
import keyboard
from time import strftime, localtime, sleep
import logging

logging.basicConfig(filename='app.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def locate_and_click(image_path):
    pos = imagesearch_loop(image_path,1)#, confidence=0.9)
    if pos[0] != -1:
        #print("position: ", pos[0], pos[1])
        logging.info("position: %s, %s", pos[0], pos[1])
        pyautogui.click(pos[0]+5, pos[1]+5)
        sleep(0.5)
        return True
    else:
        #print(" Изображение не найдено")
        logging.warning("Изображение не найдено")
        sleep(0.5)
        return False

def main():
    while True:
        print("Начало цикла, для запуска использовать ALT+Z")
        keyboard.wait('Alt + Z')
        logging.info("--------Начало цикла--------")
        sleep(1)
        if locate_and_click("pict/is1.bmp"):
            #print("Найдена картинка Изменить свойства, кликаем на него")
            logging.info("Найдена картинка Изменить свойства, кликаем на него")
            if locate_and_click("pict/zpp1.bmp"):
                #print("Нашли запрет приема платежей без галочки, кликаем по нему")
                logging.info("Нашли запрет приема платежей без галочки, кликаем по нему")
                pyautogui.scroll(-400)
                sleep(0.5)
                #print("Скролим вниз страницы")
                logging.info("Скролим вниз страницы")
                if locate_and_click("pict/save.bmp"):
                    #print("Нашли сохранить и кликнули по ней")
                    logging.info("Нашли сохранить и кликнули по ней")
                    if locate_and_click("pict/is1.bmp"):
                        #print("Нашли свойства 2")
                        logging.info("Нашли свойства 2")
                        if locate_and_click("pict/ik1.bmp"):
                            #print("Нашли изменение класса и кликнули по нему")
                            logging.info("Нашли изменение класса и кликнули по нему")
                            if locate_and_click("pict/del.bmp"):
                                #print("Нашли кнопку удаление и кликаем по ней")
                                logging.info("Нашли кнопку удаление и кликаем по ней")
                                if locate_and_click("pict/oi1.bmp"):
                                    #print("Нашли основную информацию, кликаем на нее")
                                    logging.info("Нашли основную информацию, кликаем на нее")
                                else:
                                    #print("Не найдена основная информация")
                                    logging.error("Не найдена основная информация")
                            else:
                                #print("Не найдена кнопка удаления")
                                logging.error("Не найдена кнопка удаления")
                        else:
                            #print("Не найдено изменение класса")
                            logging.error("Не найдено изменение класса")
                    else:
                        #print("Не нашли свойства 2")
                        logging.error("Не нашли свойства 2")
                else:
                    #print("Не нашли кнопку сохранить")
                    logging.error("Не нашли кнопку сохранить")
            else:
                #print("не найдена картинка пустой запрет платежей")
                logging.error("не найдена картинка пустой запрет платежей")
        else:
            #print("не найдена картинка изменить свойства")
            logging.error("не найдена картинка изменить свойства")

        sleep(0.5)
        #print("Скриншот удаленной учетки")
        logging.info("Скриншот удаленной учетки")
        pyautogui.screenshot('screen/' + strftime('%Y-%m-%d_%H.%M.%S', localtime()) + '.jpg')

if __name__ == "__main__":
    main()